let icons = document.querySelectorAll(".icons")
let responsiveBtn = document.querySelector(".responsive-menu__btn")
let resMenu = document.querySelector(".res-menu")
let classNameOfActiveEleme = "" 
let iconWrapper = ""
let iconsOfSlider = document.querySelectorAll(".icon")
let closeIcon = document.querySelector(".fa-close")
let menuItems = document.querySelectorAll(".menu-item")
menuItems.forEach(item=>{
    item.addEventListener("click",(event)=>
    {
        if(document.querySelector(".active-menu-item")){
            document.querySelector(".active-menu-item").classList.remove("active-menu-item")
        }
        event.target.classList.add("active-menu-item")
    })
})
icons.forEach(icon=>{
    icon.addEventListener("click",(event)=>{
        iconWrapper =  event.target.parentElement
        classNameOfActiveEleme = event.target.getAttribute("box-name")
        if(document.querySelector(`.active-box`)){
            document.querySelector(".active-box").classList.remove("active-box")
            
        }
        document.querySelector(`.${classNameOfActiveEleme}`).classList.add("active-box")
        if(document.querySelector(".active-icon")){
            document.querySelector(".active-icon").classList.remove("active-icon")
        }
        iconWrapper.classList.add("active-icon")
    })
})
closeIcon.addEventListener("click",(event)=>{
    responsiveBtn.classList.remove("active-res-btn")
    resMenu.classList.remove("open-menu")
})
responsiveBtn.addEventListener('click',()=>{
    responsiveBtn.classList.toggle("active-res-btn")
    resMenu.classList.toggle("open-menu")
})
let counter = 0

setInterval(()=>{
    
    counter += 1
    if(counter > iconsOfSlider.length){
        counter = 0
    } 
    iconsOfSlider[counter].click()
},5000)
