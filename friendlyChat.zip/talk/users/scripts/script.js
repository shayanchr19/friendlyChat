let copyLinkIcon = document.querySelector(".fa-chain")
let hambtn = document.querySelector(".responsive-btn")
let resMenu = document.querySelector(".responsive-menu")
let menuItems = document.querySelectorAll(".d-item")
let closeIconOfResponsiveMenu = document.querySelector(".fa-close") 
let copyValue = document.querySelector(".user-link").innerText
let replay = document.querySelectorAll(".fa-reply")

copyLinkIcon.addEventListener('click',()=>{
    navigator.clipboard.writeText(copyValue)
    swal("کپی شد","لینک با موفقیت کپی شد","success")

})

hambtn.addEventListener('click',()=>{
    hambtn.classList.toggle("active-btn")
    resMenu.classList.toggle("active-menu")
})
let targetElem = ''
menuItems.forEach(item=>{
    item.addEventListener("click",(event)=>{
        targetElem = event.target
        if(document.querySelector(".active-item")){
            document.querySelector(".active-item").classList.remove("active-item")
        }
        targetElem.classList.add("active-item")
    })
})

closeIconOfResponsiveMenu.addEventListener("click",()=>{
    resMenu.classList.remove("active-menu")
    hambtn.classList.remove("active-btn")
})

let boxes = document.querySelectorAll(".bx");
// console.log(boxes)
if(boxes.length < 2){
    boxes.forEach(box=>{
        box.className = "col-12 col-sm-12 col-md-12 col-lg-12"
    })

}

let messagesBox = document.querySelectorAll(".message-wrapper")
messagesBox.forEach(item=>{
    if(item.innerText.length > 80){
        item.style.overflowY =  "scroll";
    }
})


let dlBtns = document.querySelectorAll(".dl-status")
let parentElem = ""
let textMessage = ""
let nodes = ""
dlBtns.forEach(dlBtn=>{
        dlBtn.addEventListener("click",(event)=>{
           
            parentElem = event.target.parentElement.parentElement.parentElement.parentElement.parentElement
            console.log(parentElem) 
            nodes = parentElem.childNodes
            console.log(nodes[1])
            textMessage = nodes[1]
            let urlSite = document.createElement("span")
            urlSite.setAttribute("class","url-site")
            urlSite.innerHTML = "Friendlychat.ir"
            textMessage.append(urlSite)
            textMessage.style.backgroundColor = "#1A2639"
            textMessage.style.padding = "1rem 3rem"
            textMessage.style.borderTopLeftRadius = "1rem"
            textMessage.style.borderTopRightRadius = "1rem"
            textMessage.style.borderBottomLeftRadius = "1rem"

            textMessage.style.width = "100%"
            textMessage.style.height = "100%"
            textMessage.style.border = "2px solid #C24D2C"
            textMessage.style.textAlign = "left"

            html2canvas(textMessage, {
                onrendered: function (canvas) {
                    let s = document.getElementById("textScreenshot")
                    s.style.width = "100%"
                    s.style.height = "100%"
                var screenshot = canvas.toDataURL('image/jpeg');
                document.getElementById('textScreenshot').setAttribute('src', screenshot);
                let  a = document.createElement("a")
                a.href = document.getElementById('textScreenshot').getAttribute('src');

                a.download = "استوری پیام"
                a.click()
                location.href = location.href
                },
            });
          
        
           
        })
})
let cancel = document.querySelectorAll(".cancel")
cancel.forEach(item=>{

    item.addEventListener("click",(event)=>{
        let formElem = event.target.parentElement.parentElement.parentElement.parentElement.parentElement
        formElem.classList.remove("active-box")
    })
})

let forms = document.querySelectorAll(".form")
let flagForm = ""
replay.forEach(item=>{
    item.addEventListener("click",(event)=>{
        // console.log(event.target.parentElement.parentElement.childNodes[1].childNodes[3].classList.toggle("active-box"))
        // let pElem = event.target.parentElement.childNodes[1].childNodes[3].childNodes[1]
        // pElem.classList.toggle("active-box")
        let pelem = event.target.parentElement.childNodes[1].childNodes[3].childNodes[1]        
        pelem.classList.toggle("active-box")
        
    })
})
let containerMessages = ""
let messages = document.querySelectorAll(".box-message")
let dlAllMessage = document.querySelector(".dl-all-message")
containerMessages = document.createElement("div")
containerMessages.className = "messagesContainer"

dlAllMessage.addEventListener("click",()=>{
    messages.forEach(item=>{
        item.style.padding = "1rem 3rem"
        item.style.backgroundColor = "red"
        let urlSite = document.createElement("span")
        urlSite.setAttribute("class","url-site")
        urlSite.innerHTML = "Friendlychat.ir"
        let hrEleme = document.createElement("br")
        containerMessages.append(`${item.innerHTML}`)
        containerMessages.append(hrEleme)
        containerMessages.append(urlSite)
    })
    document.body.appendChild(containerMessages)

    dl()
})



function dl(){
    
    html2canvas(containerMessages, {
        onrendered: function (canvas) {
            let s = document.getElementById("textScreenshot")
            s.style.width = "100%"
            s.style.height = "100%"
        var screenshot = canvas.toDataURL('image/jpeg');
        document.getElementById('textScreenshot').setAttribute('src', screenshot);
        let  a = document.createElement("a")
        a.href = document.getElementById('textScreenshot').getAttribute('src');
    
        a.download = "استوری پیام"
        a.click()
        location.href = location.href
        },
    });
}
    
    