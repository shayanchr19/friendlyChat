let dlStatus = document.querySelector(".dl-status")
let textMessage = document.querySelector(".messages-wrapper")

dlStatus.addEventListener("click",(event)=>{
    let urlSite = document.createElement("span")
    urlSite.setAttribute("class","url-site")
    urlSite.innerHTML = "Friendlychat.ir"
    textMessage.append(urlSite)
    textMessage.style.backgroundColor = "#1A2639"
    textMessage.style.padding = "1rem 3rem"
    textMessage.style.borderTopLeftRadius = "1rem"
    textMessage.style.borderTopRightRadius = "1rem"
    textMessage.style.borderBottomLeftRadius = "1rem"
    textMessage.style.border = "2px solid #C24D2C"
    textMessage.style.textAlign = "left"
    html2canvas(textMessage, {
        onrendered: function (canvas) {
            let s = document.getElementById("textScreenshot")
            s.style.width = "100%"
            s.style.height = "100%"
        var screenshot = canvas.toDataURL('image/jpeg');
        document.getElementById('textScreenshot').setAttribute('src', screenshot);
        let  a = document.createElement("a")

       

        a.href = document.getElementById('textScreenshot').getAttribute('src');
    
        a.download = "استوری پیام"
        a.click()
        location.href = location.href
        },
    });
})

