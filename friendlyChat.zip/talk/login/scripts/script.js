let copyLinkIcon = document.querySelector(".fa-chain")
let hambtn = document.querySelector(".responsive-btn")
let resMenu = document.querySelector(".responsive-menu")
let menuItems = document.querySelectorAll(".d-item")
let closeIconOfResponsiveMenu = document.querySelector(".fa-close") 
let copyValue = document.querySelector(".user-link").innerText
console.log(copyValue)
copyLinkIcon.addEventListener('click',()=>{
    navigator.clipboard.writeText(copyValue)
    swal("کپی شد","لینک با موفقیت کپی شد","success")

})

hambtn.addEventListener('click',()=>{
    hambtn.classList.toggle("active-btn")
    resMenu.classList.toggle("active-menu")
})
let targetElem = ''
menuItems.forEach(item=>{
    item.addEventListener("click",(event)=>{
        targetElem = event.target
        if(document.querySelector(".active-item")){
            document.querySelector(".active-item").classList.remove("active-item")
        }
        targetElem.classList.add("active-item")
    })
})

closeIconOfResponsiveMenu.addEventListener("click",()=>{
    resMenu.classList.remove("active-menu")
    hambtn.classList.remove("active-btn")
})

let boxes = document.querySelectorAll(".bx");
// console.log(boxes)
if(boxes.length < 2){
    boxes.forEach(box=>{
        box.className = "col-12 col-sm-12 col-md-12 col-lg-12"
    })

}

let messagesBox = document.querySelectorAll(".message-wrapper")
messagesBox.forEach(item=>{
    if(item.innerText.length > 80){
        item.style.overflowY =  "scroll";
    }
})


let dlBtns = document.querySelectorAll(".dl-status")
console.log(dlBtns)
//   html2canvas(document.getElementById('talltweets'), {
//     onrendered: function (canvas) {
//       var screenshot = canvas.toDataURL('image/png');
//       document.getElementById('textScreenshot').setAttribute('src', screenshot);
//     let  a = document.createElement("a")
//     a.href = screenshot
//     a.click()
//     },
//   });
