let copyLinkIcon = document.querySelector(".fa-link")
let hambtn = document.querySelector(".responsive-btn")
let resMenu = document.querySelector(".responsive-menu")
let menuItems = document.querySelectorAll(".d-item")
let closeIconOfResponsiveMenu = document.querySelector(".fa-close") 
let copyValue = document.querySelector(".link-value").innerText
console.log(copyValue)
copyLinkIcon.addEventListener('click',()=>{
    navigator.clipboard.writeText(copyValue)
    swal("کپی شد","لینک با موفقیت کپی شد","success")

})

hambtn.addEventListener('click',()=>{
    hambtn.classList.toggle("active-btn")
    resMenu.classList.toggle("active-menu")
})
let targetElem = ''
menuItems.forEach(item=>{
    item.addEventListener("click",(event)=>{
        targetElem = event.target
        if(document.querySelector(".active-item")){
            document.querySelector(".active-item").classList.remove("active-item")
        }
        targetElem.classList.add("active-item")
    })
})

closeIconOfResponsiveMenu.addEventListener("click",()=>{
    resMenu.classList.remove("active-menu")
    hambtn.classList.remove("active-btn")
})